
import './App.css';
import MemeGenerator from './MemeGenerator.js';
import Header from './Header.js';
function App() {
  return (
    <div className="App">
      <Header/>
      <MemeGenerator/>
    </div>
  );
}

export default App;
