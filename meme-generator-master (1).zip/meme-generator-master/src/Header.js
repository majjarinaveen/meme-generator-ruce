import React from 'react'

export default function Header() {
  return (
    <div>
      <header style={{backgroundColor:'aqua'}}>

        <img style={{ margin:5}} src="https://upload.wikimedia.org/wikipedia/en/9/9a/Trollface_non-free.png"  width={70} alt="image" />

             <h1 style={{display:'inline', margin:20}}>Meme Generator</h1>
      </header>
    </div>
  )
}
